// Assignment #: 1 
//         Name: Kiara Wilborn 
//    StudentID: 1216988422
//      Lecture:MWF 8:35-9:25 am
//  Description: (1)This class reads an integer from a keyboard and prints it out
//               along with other messages.
//				 (2)The purpose of this assignment is let you be familiar with the assignments submission
//				 server. Make sure to modify the original program in such a way that your outputs match
//				 exactly the outputs we provided!

import java.util.Scanner; 

    public class Assignment1 {
  
    
    
 
      public static void main (String[] args) {
  System.out.println ("Enter Number") ;
  
  Scanner console = new Scanner(System.in);
      

  String number = console.nextLine ();
  System.out.println ("You entered " + number );
  
  console.close();


   
  }
    
}


